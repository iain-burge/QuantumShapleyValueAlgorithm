% Test script for the Quantum Information Toolkit

% Ville Bergholm 2009-2010

test_utils
test_state
markov.test_markov
disp('All tests passed.')
